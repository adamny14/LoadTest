#------------------------------
# Adam Hussain
# print a square of stars for n
#------------------------------
n = input("Enter number n: ");
counter = 1;
while counter <= n:
    print("*"*n);
    counter = counter +1;
