#-------------------------------------
# Adam Hussain
# print out squares of numbers until n
#-------------------------------------
n = input("Enter number: ");
counter = 1;
while counter <= n:
    print(counter * counter);
    counter = counter+1;
