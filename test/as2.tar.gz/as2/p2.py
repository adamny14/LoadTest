#-------------------------------
# Adam Hussain
# print sum 1 to n
#-------------------------------
n = input("Enter a number: ");
counter = 1;
sum = 0;
while counter <= n:
    sum = sum + counter;
    counter = counter + 1;
print(sum);
